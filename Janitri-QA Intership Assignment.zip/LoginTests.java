
package com.janitri.tests;

import com.janitri.base.BaseTest;
import com.janitri.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTests extends BaseTest {

    @Test
    public void testBlankFieldsLoginButtonDisabled() {
        LoginPage loginPage = new LoginPage(driver);
        Assert.assertFalse(loginPage.isLoginButtonEnabled(), "Login button should be disabled when fields are blank");
    }

    @Test
    public void testRandomInvalidCredentialsShowError() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.enterUserId("fakeuser@example.com");
        loginPage.enterPassword("wrongpass123");
        loginPage.clickLogin();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {}

        String errorMessage = loginPage.getErrorMessage();
        System.out.println("Captured Error Message: " + errorMessage);
        Assert.assertTrue(errorMessage != null && !errorMessage.isEmpty(), "Error message should be shown for invalid credentials");
    }

    @Test
    public void testPasswordMaskingToggle() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.enterPassword("mypassword");

        Assert.assertTrue(loginPage.isPasswordMasked(), "Password should be masked initially");

        loginPage.togglePasswordVisibility();
        Assert.assertFalse(loginPage.isPasswordMasked(), "Password should be visible after clicking eye icon");

        loginPage.togglePasswordVisibility();
        Assert.assertTrue(loginPage.isPasswordMasked(), "Password should be masked again after toggle");
    }

    @Test
    public void testPresenceOfPageElements() {
        LoginPage loginPage = new LoginPage(driver);

        Assert.assertTrue(loginPage.isUserIdFieldDisplayed(), "User ID field should be displayed");
        Assert.assertTrue(loginPage.isPasswordFieldDisplayed(), "Password field should be displayed");
        Assert.assertTrue(loginPage.isEyeIconDisplayed(), "Password visibility toggle should be displayed");
        Assert.assertTrue(loginPage.isLoginButtonDisplayed(), "Login button should be displayed");
        Assert.assertTrue(loginPage.isTitleDisplayed(), "Page title should be displayed");

        System.out.println("Page Title: " + loginPage.getPageTitle());
    }
}
